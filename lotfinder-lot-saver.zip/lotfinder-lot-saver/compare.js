"use strict";
// Compare page: the user's saved lots (Copart, IAAI, eBay) and every live eBay lot from the
// public LotFinder site, ranked together by estimated margin.

const $ = (id) => document.getElementById(id);
const usd = (c) => (c < 0 ? "-$" : "$") + Math.round(Math.abs(c) / 100).toLocaleString("en-US");
const SITE = { copart: "Copart", iaai: "IAAI", ebay: "eBay" };
// The public LotFinder site: its lot list and eBay values (read-only JSON, sent with CORS *).
const LOTFINDER_SITE = "https://jbon007-92.github.io/lotfinder-demo/";
let pricing = null;
let lots = {};
let siteLots = [];
let siteValues = null;
let siteParts = null;
let siteNote = "";

function el(tag, attrs = {}, ...kids) {
  const n = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === "text") n.textContent = v;
    else if (k === "class") n.className = v;
    else n.setAttribute(k, v);
  }
  for (const k of kids) if (k != null) n.append(k);
  return n;
}

async function store() {
  await chrome.storage.local.set({ lots });
  render();
}

function card(r, i) {
  const s = r.saved;
  const d = r.deal;
  const photo = LotStoreSafe(s.photos && s.photos[0]);
  const live = s.origin === "live";
  const bid = live ? el("b", { text: usd(s.current_bid_cents) }) : el("input", { type: "number", min: "0", step: "1", value: s.current_bid_cents == null ? "" : String(Math.round(s.current_bid_cents / 100)), "aria-label": "Current bid" });
  if (!live) {
    bid.addEventListener("change", () => {
      s.current_bid_cents = bid.value === "" ? null : Math.round(Number(bid.value) * 100);
      s.updated_at = new Date().toISOString();
      store();
    });
  }
  const kbb = LotScore.kbbUrl(s.year, s.make, s.model);
  const kbbA = kbb ? el("a", { href: kbb, target: "_blank", rel: "noopener noreferrer", text: "KBB value ↗" }) : null;
  const del = live ? null : el("button", { type: "button", class: "link", text: "Remove" });
  if (del) {
    del.addEventListener("click", () => {
      delete lots[s.id];
      store();
    });
  }
  const link = LotStoreSafe(s.url) ? el("a", { href: LotStoreSafe(s.url), target: "_blank", rel: "noopener noreferrer", text: "open listing ↗" }) : null;
  const money = d.error
    ? el("p", { class: "notice", text: "Can't score yet: " + d.error + ". Open the listing and click the toolbar button to fill it in." })
    : el("table", {},
        row("Bid + fees", d.bid_cents + d.fees_cents),
        row("Est. repairs (" + d.repair_lines.length + " parts)", d.repairs_cents),
        row("Transport", d.transport_cents),
        row("All-in", d.all_in_cents, "total"),
        row(VALUE_LABEL[d.value_from] ? VALUE_LABEL[d.value_from](d) : "Value once fixed (est.)", d.market_value_cents));
  const margin = d.error ? null : el("div", { class: "margin " + (d.margin_cents >= 0 ? "pos" : "neg"), text: `${usd(d.margin_cents)} est. margin (${d.margin_pct}%)` });
  return el("article", { class: "lot" },
    el("div", { class: "rank", text: String(i + 1) }),
    photo ? el("img", { src: photo, alt: "", referrerpolicy: "no-referrer", loading: "lazy" }) : el("div", { class: "nophoto", text: "no photo" }),
    el("div", { class: "info" },
      el("h3", { text: `${s.year || "?"} ${s.make || "?"} ${s.model || ""}` }),
      el("span", { class: "tag " + (live ? "live" : "saved"), text: live ? "Live on LotFinder" : "Saved by you" }),
      el("p", { class: "meta", text: [SITE[s.source] + (s.lot_number ? " " + s.lot_number : ""), s.odometer_mi != null ? Number(s.odometer_mi).toLocaleString("en-US") + " mi" : "", s.title_type, s.primary_damage, s.location].filter(Boolean).join(" · ") }),
      d.value_known === false ? el("p", { class: "notice", text: "No value figure for this model: margin is not meaningful until you type a value." }) : null,
      el("p", { class: "meta" }, el("label", {}, "Bid $ ", bid), " ", link, " ", kbbA, " ", del),
      partsLine(s)),
    el("div", { class: "money" }, margin, money));
}

// Used parts on eBay for this car: the published price when LotFinder has one, else a link.
function partsLine(s) {
  const parts = LotScore.partsFor(siteParts, s.year, s.make, s.model);
  if (!parts.length) return null;
  const p = el("p", { class: "meta parts-line" }, "Used parts (eBay): ");
  parts.forEach((x, i) => {
    if (i) p.append(" · ");
    p.append(el("a", { href: x.url, target: "_blank", rel: "noopener noreferrer", title: x.n ? `${x.n} listings, ${usd(x.low_cents)}–${usd(x.high_cents)}` : "search eBay", text: x.label + (x.median_cents != null ? " " + usd(x.median_cents) : "") }));
  });
  return p;
}

// Only https images are shown (extract.js already keeps https only; checked again here).
function LotStoreSafe(u) {
  try {
    return u && new URL(u).protocol === "https:" ? u : null;
  } catch {
    return null;
  }
}

const VALUE_LABEL = {
  typed: () => "Value once fixed (yours)",
  ebay: (d) => `Value (eBay median, ${d.value_n} listings)`,
  table: () => "Value (rough estimate)",
  none: () => "Value (none)",
};

function row(label, cents, cls = "") {
  return el("tr", { class: cls }, el("td", { text: label }), el("td", { class: "n", text: usd(cents) }));
}

let ranked = [];
function render() {
  const all = LotStore.rank(pricing, LotStore.merge(Object.values(lots), siteLots), siteValues);
  const want = $("site").value;
  ranked = all.filter((r) => want === "all" || (want === "saved" ? r.saved.origin !== "live" : r.saved.source === want));
  $("empty").hidden = Object.keys(lots).length > 0;
  $("count").textContent = `${ranked.length} lot${ranked.length === 1 ? "" : "s"}`;
  $("siteNote").textContent = siteNote;
  $("siteNote").hidden = !siteNote;
  $("list").replaceChildren(...ranked.map(card));
}

// Live eBay lots and eBay values from the LotFinder site; saved lots still show without them.
async function loadSite() {
  try {
    const get = async (path) => {
      const r = await fetch(LOTFINDER_SITE + path, { cache: "no-cache", credentials: "omit" });
      if (!r.ok) throw new Error(r.status + " " + r.statusText);
      return r.json();
    };
    const [l, v, p] = await Promise.all([
      get("api/lots.json"), get("api/values.json").catch(() => null), get("api/parts.json").catch(() => null),
    ]);
    siteParts = p && Array.isArray(p.cars) ? p : null;
    siteLots = Array.isArray(l.lots) ? l.lots : [];
    siteValues = v && Array.isArray(v.values) ? v : null;
    siteNote = "";
  } catch (err) {
    siteNote = "Could not load the live lots from LotFinder (" + err.message + "): showing your saved lots only.";
  }
  render();
}

function exportCsv() {
  const blob = new Blob([LotStore.toCsv(ranked)], { type: "text/csv" });
  const a = el("a", { href: URL.createObjectURL(blob), download: "lotfinder-saved-lots.csv" });
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}

async function init() {
  pricing = await (await fetch("pricing.json")).json();
  ({ lots = {} } = await chrome.storage.local.get("lots"));
  $("csv").addEventListener("click", exportCsv);
  $("site").addEventListener("change", render);
  chrome.storage.onChanged.addListener((changes) => {
    if (changes.lots) {
      lots = changes.lots.newValue || {};
      render();
    }
  });
  render();
  loadSite();
}

init();
