"use strict";
// Compare page: every saved lot from every site, ranked by estimated margin.

const $ = (id) => document.getElementById(id);
const usd = (c) => (c < 0 ? "-$" : "$") + Math.round(Math.abs(c) / 100).toLocaleString("en-US");
const SITE = { copart: "Copart", iaai: "IAAI", ebay: "eBay" };
let pricing = null;
let lots = {};

function el(tag, attrs = {}, ...kids) {
  const n = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === "text") n.textContent = v;
    else if (k === "class") n.className = v;
    else n.setAttribute(k, v);
  }
  for (const k of kids) if (k != null) n.append(k);
  return n;
}

async function store() {
  await chrome.storage.local.set({ lots });
  render();
}

function card(r, i) {
  const s = r.saved;
  const d = r.deal;
  const photo = LotStoreSafe(s.photos && s.photos[0]);
  const bid = el("input", { type: "number", min: "0", step: "1", value: s.current_bid_cents == null ? "" : String(Math.round(s.current_bid_cents / 100)), "aria-label": "Current bid" });
  bid.addEventListener("change", () => {
    s.current_bid_cents = bid.value === "" ? null : Math.round(Number(bid.value) * 100);
    s.updated_at = new Date().toISOString();
    store();
  });
  const kbb = LotScore.kbbUrl(s.year, s.make, s.model);
  const kbbA = kbb ? el("a", { href: kbb, target: "_blank", rel: "noopener noreferrer", text: "KBB value ↗" }) : null;
  const del = el("button", { type: "button", class: "link", text: "Remove" });
  del.addEventListener("click", () => {
    delete lots[s.id];
    store();
  });
  const link = s.url ? el("a", { href: s.url, target: "_blank", rel: "noopener noreferrer", text: "open listing ↗" }) : null;
  const money = d.error
    ? el("p", { class: "notice", text: "Can't score yet: " + d.error + ". Open the listing and click the toolbar button to fill it in." })
    : el("table", {},
        row("Bid + fees", d.bid_cents + d.fees_cents),
        row("Est. repairs (" + d.repair_lines.length + " parts)", d.repairs_cents),
        row("Transport", d.transport_cents),
        row("All-in", d.all_in_cents, "total"),
        row(s.market_value_cents != null ? "Value once fixed (yours)" : "Value once fixed (est.)", d.market_value_cents));
  const margin = d.error ? null : el("div", { class: "margin " + (d.margin_cents >= 0 ? "pos" : "neg"), text: `${usd(d.margin_cents)} est. margin (${d.margin_pct}%)` });
  return el("article", { class: "lot" },
    el("div", { class: "rank", text: String(i + 1) }),
    photo ? el("img", { src: photo, alt: "", referrerpolicy: "no-referrer", loading: "lazy" }) : el("div", { class: "nophoto", text: "no photo" }),
    el("div", { class: "info" },
      el("h3", { text: `${s.year || "?"} ${s.make || "?"} ${s.model || ""}` }),
      el("p", { class: "meta", text: [SITE[s.source] + (s.lot_number ? " " + s.lot_number : ""), s.odometer_mi != null ? Number(s.odometer_mi).toLocaleString("en-US") + " mi" : "", s.title_type, s.primary_damage, s.location].filter(Boolean).join(" · ") }),
      d.value_known === false ? el("p", { class: "notice", text: "No value figure for this model: margin is not meaningful until you type a value." }) : null,
      el("p", { class: "meta" }, el("label", {}, "Bid $ ", bid), " ", link, " ", kbbA, " ", del)),
    el("div", { class: "money" }, margin, money));
}

// Only https images are shown (extract.js already keeps https only; checked again here).
function LotStoreSafe(u) {
  try {
    return u && new URL(u).protocol === "https:" ? u : null;
  } catch {
    return null;
  }
}

function row(label, cents, cls = "") {
  return el("tr", { class: cls }, el("td", { text: label }), el("td", { class: "n", text: usd(cents) }));
}

let ranked = [];
function render() {
  ranked = LotStore.rank(pricing, Object.values(lots));
  $("empty").hidden = ranked.length > 0;
  $("list").replaceChildren(...ranked.map(card));
}

function exportCsv() {
  const blob = new Blob([LotStore.toCsv(ranked)], { type: "text/csv" });
  const a = el("a", { href: URL.createObjectURL(blob), download: "lotfinder-saved-lots.csv" });
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}

async function init() {
  pricing = await (await fetch("pricing.json")).json();
  ({ lots = {} } = await chrome.storage.local.get("lots"));
  $("csv").addEventListener("click", exportCsv);
  chrome.storage.onChanged.addListener((changes) => {
    if (changes.lots) {
      lots = changes.lots.newValue || {};
      render();
    }
  });
  render();
}

init();
