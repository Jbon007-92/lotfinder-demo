"use strict";
// Saved lots: scoring, ranking and CSV export. Pure (no chrome.*), tested in node.
// A saved lot is an extracted lot (extract.js) plus what the user typed:
//   {id, saved_at, parts: {part: "replace"|"repair"}, market_value_cents|null, transport_cents|null}

(function (root) {
  const Score = root.LotScore || (typeof require === "function" ? require("./score.js") : null);

  const lotId = (lot) => lot.source + ":" + (lot.lot_number || lot.url);

  // Market value from the LotFinder site's eBay figures (api/values.json) for the same
  // make, model and year (else a year either side), moved for miles and title like the site.
  function ebayValue(values, pricing, lot) {
    if (!values || !values.values || !pricing.values) return null;
    const mk = String(lot.make).toLowerCase();
    const md = String(lot.model).toLowerCase();
    const y = Number(lot.year);
    const pick = (yr) => values.values.find((v) => v.make === mk && v.model === md && v.year === yr);
    const hit = pick(y) || pick(y - 1) || pick(y + 1);
    if (!hit) return null;
    const f = pricing.values;
    let value = Math.round(hit.median_cents * (1 - values.trim));
    const expected = f.ref_miles * Math.max(f.now_year - y, 1);
    const cap = value * f.mileage_cap;
    value += Math.max(-cap, Math.min(cap, (expected - (Number(lot.odometer_mi) || 0)) * f.per_mile_cents));
    const disc = Object.prototype.hasOwnProperty.call(f.title_discount, lot.title_type)
      ? f.title_discount[lot.title_type]
      : f.default_title_discount;
    return { cents: Math.max(Math.trunc(value * (1 - disc)), 0), n: hit.n };
  }

  // A lot from the LotFinder site (api/lots.json) in the saved-lot shape, read-only.
  function fromSite(s) {
    const basis = s.value_basis || {};
    return {
      id: "live:" + s.id,
      origin: "live",
      source: s.source,
      lot_number: String(s.id).replace(/^E-/, ""),
      url: s.url || "",
      year: s.year,
      make: s.make,
      model: s.model,
      odometer_mi: s.odometer_mi,
      title_type: s.title_type,
      primary_damage: s.primary_damage,
      location: s.location,
      current_bid_cents: s.bid_cents,
      photos: s.thumb && /^https:/.test(s.thumb) ? [s.thumb] : [],
      parts: {},
      market_value_cents: basis.kind === "none" ? null : s.market_value_cents,
      value_from: basis.kind === "ebay" ? "ebay" : basis.kind === "none" ? "none" : "table",
      value_n: basis.n || 0,
      transport_cents: null,
    };
  }

  // Saved lots and live site lots in one list; a lot saved by the user wins over its live copy.
  function merge(savedLots, siteLots) {
    const seen = new Set(savedLots.map(lotId));
    return [...savedLots, ...siteLots.map(fromSite).filter((l) => !seen.has(lotId(l)))];
  }

  // What the seller says is wrong (same rules as the site: core/faults.py via pricing.json).
  function faultsFor(pricing, text) {
    const f = pricing && pricing.faults;
    if (!f || !text) return { faults: [], vague: "" };
    const before = new RegExp(f.denied_before, "i");
    const after = new RegExp(f.denied_after, "i");
    const quote = (s, a, b) => {
      const left = Math.max(s.lastIndexOf(".", a), s.lastIndexOf("!", a), s.lastIndexOf("\n", a));
      const ends = [s.indexOf(".", b), s.indexOf("!", b), s.indexOf("\n", b)].filter((i) => i !== -1);
      const q = s.slice(left + 1, ends.length ? Math.min(...ends) : s.length).replace(/\s+/g, " ").trim();
      return q.length <= 160 ? q : q.slice(0, 157) + "...";
    };
    const out = [];
    for (const [key, label, pattern, parts, worse] of f.rules) {
      const re = new RegExp(pattern, "gi");
      let m;
      while ((m = re.exec(text))) {
        const pre = text.slice(Math.max(0, m.index - 30), m.index);
        const post = text.slice(m.index + m[0].length, m.index + m[0].length + 40);
        if (before.test(pre) || after.test(post)) continue;
        out.push({ key, label, parts, worse, quote: quote(text, m.index, m.index + m[0].length) });
        break;
      }
    }
    let vague = "";
    if (!out.length) {
      const re = new RegExp(f.vague, "gi");
      let m;
      while ((m = re.exec(text))) {
        if (before.test(text.slice(Math.max(0, m.index - 30), m.index))) continue;
        vague = quote(text, m.index, m.index + m[0].length);
        break;
      }
    }
    return { faults: out, vague };
  }

  function scoreSaved(pricing, saved, values) {
    if (!saved.year || !saved.make || !saved.model || saved.current_bid_cents == null) {
      return { error: "needs year, make, model and the current bid" };
    }
    if (!pricing.fees[saved.source]) return { error: "no fee table for " + saved.source };
    const lot = {
      source: saved.source,
      year: Number(saved.year),
      make: saved.make,
      model: saved.model,
      odometer_mi: Number(saved.odometer_mi) || 0,
      title_type: saved.title_type || "salvage",
      current_bid_cents: saved.current_bid_cents,
    };
    const findings = Object.entries(saved.parts || {})
      .filter(([, action]) => action === "replace" || action === "repair")
      .map(([part, action]) => ({ part, action, confidence: 1.0 }));
    let market = saved.market_value_cents ?? null;
    let valueFrom = saved.origin === "live" ? saved.value_from : market != null ? "typed" : "table";
    let valueN = saved.value_n || 0;
    if (market == null && saved.origin !== "live") {
      const e = ebayValue(values, pricing, lot);
      if (e) [market, valueFrom, valueN] = [e.cents, "ebay", e.n];
    }
    const d = Score.score(pricing, lot, findings, market, saved.transport_cents ?? null);
    d.value_from = valueFrom;
    d.value_n = valueN;
    d.value_known = valueFrom !== "none" && (market != null || d.market_value_cents > 0);
    return d;
  }

  // Best deal first; lots that cannot be scored (or have no value figure) go last.
  function rank(pricing, savedLots, values) {
    const rows = savedLots.map((s) => ({ saved: s, deal: scoreSaved(pricing, s, values) }));
    const key = (r) => (r.deal.error ? 2 : r.deal.value_known ? 0 : 1);
    return rows.sort(
      (a, b) => key(a) - key(b) || (b.deal.margin_cents || 0) - (a.deal.margin_cents || 0),
    );
  }

  const CSV_COLS = [
    ["source", (r) => r.saved.source],
    ["from", (r) => (r.saved.origin === "live" ? "live on LotFinder" : "saved by you")],
    ["lot_number", (r) => r.saved.lot_number],
    ["year", (r) => r.saved.year],
    ["make", (r) => r.saved.make],
    ["model", (r) => r.saved.model],
    ["miles", (r) => r.saved.odometer_mi],
    ["title", (r) => r.saved.title_type],
    ["damage", (r) => r.saved.primary_damage],
    ["bid", (r) => dollars(r.saved.current_bid_cents)],
    ["fees", (r) => dollars(r.deal.fees_cents)],
    ["est_repairs", (r) => dollars(r.deal.repairs_cents)],
    ["transport", (r) => dollars(r.deal.transport_cents)],
    ["all_in", (r) => dollars(r.deal.all_in_cents)],
    ["market_value", (r) => dollars(r.deal.market_value_cents)],
    ["est_margin", (r) => dollars(r.deal.margin_cents)],
    ["url", (r) => r.saved.url],
  ];
  const dollars = (c) => (c == null ? "" : (c / 100).toFixed(2));
  const cell = (v) => {
    let s = v == null ? "" : String(v);
    if (/^[=+\-@\t\r]/.test(s)) s = "'" + s; // no formulas when opened in a spreadsheet
    return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
  };
  function toCsv(rows) {
    const out = [CSV_COLS.map(([h]) => h).join(",")];
    for (const r of rows) out.push(CSV_COLS.map(([, f]) => cell(f(r))).join(","));
    return out.join("\n") + "\n";
  }

  const LotStore = { faultsFor, lotId, scoreSaved, rank, toCsv, merge, fromSite, ebayValue };
  if (typeof module !== "undefined" && module.exports) module.exports = LotStore;
  else root.LotStore = LotStore;
})(typeof globalThis !== "undefined" ? globalThis : this);
