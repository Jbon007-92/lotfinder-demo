"use strict";
// Saved lots: scoring, ranking and CSV export. Pure (no chrome.*), tested in node.
// A saved lot is an extracted lot (extract.js) plus what the user typed:
//   {id, saved_at, parts: {part: "replace"|"repair"}, market_value_cents|null, transport_cents|null}

(function (root) {
  const Score = root.LotScore || (typeof require === "function" ? require("./score.js") : null);

  const lotId = (lot) => lot.source + ":" + (lot.lot_number || lot.url);

  function scoreSaved(pricing, saved) {
    if (!saved.year || !saved.make || !saved.model || saved.current_bid_cents == null) {
      return { error: "needs year, make, model and the current bid" };
    }
    if (!pricing.fees[saved.source]) return { error: "no fee table for " + saved.source };
    const lot = {
      source: saved.source,
      year: Number(saved.year),
      make: saved.make,
      model: saved.model,
      odometer_mi: Number(saved.odometer_mi) || 0,
      title_type: saved.title_type || "salvage",
      current_bid_cents: saved.current_bid_cents,
    };
    const findings = Object.entries(saved.parts || {})
      .filter(([, action]) => action === "replace" || action === "repair")
      .map(([part, action]) => ({ part, action, confidence: 1.0 }));
    const d = Score.score(pricing, lot, findings, saved.market_value_cents ?? null, saved.transport_cents ?? null);
    d.value_known = saved.market_value_cents != null || d.market_value_cents > 0;
    return d;
  }

  // Best deal first; lots that cannot be scored (or have no value figure) go last.
  function rank(pricing, savedLots) {
    const rows = savedLots.map((s) => ({ saved: s, deal: scoreSaved(pricing, s) }));
    const key = (r) => (r.deal.error ? 2 : r.deal.value_known ? 0 : 1);
    return rows.sort(
      (a, b) => key(a) - key(b) || (b.deal.margin_cents || 0) - (a.deal.margin_cents || 0),
    );
  }

  const CSV_COLS = [
    ["source", (r) => r.saved.source],
    ["lot_number", (r) => r.saved.lot_number],
    ["year", (r) => r.saved.year],
    ["make", (r) => r.saved.make],
    ["model", (r) => r.saved.model],
    ["miles", (r) => r.saved.odometer_mi],
    ["title", (r) => r.saved.title_type],
    ["damage", (r) => r.saved.primary_damage],
    ["bid", (r) => dollars(r.saved.current_bid_cents)],
    ["fees", (r) => dollars(r.deal.fees_cents)],
    ["est_repairs", (r) => dollars(r.deal.repairs_cents)],
    ["transport", (r) => dollars(r.deal.transport_cents)],
    ["all_in", (r) => dollars(r.deal.all_in_cents)],
    ["market_value", (r) => dollars(r.deal.market_value_cents)],
    ["est_margin", (r) => dollars(r.deal.margin_cents)],
    ["url", (r) => r.saved.url],
  ];
  const dollars = (c) => (c == null ? "" : (c / 100).toFixed(2));
  const cell = (v) => {
    let s = v == null ? "" : String(v);
    if (/^[=+\-@\t\r]/.test(s)) s = "'" + s; // no formulas when opened in a spreadsheet
    return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
  };
  function toCsv(rows) {
    const out = [CSV_COLS.map(([h]) => h).join(",")];
    for (const r of rows) out.push(CSV_COLS.map(([, f]) => cell(f(r))).join(","));
    return out.join("\n") + "\n";
  }

  const LotStore = { lotId, scoreSaved, rank, toCsv };
  if (typeof module !== "undefined" && module.exports) module.exports = LotStore;
  else root.LotStore = LotStore;
})(typeof globalThis !== "undefined" ? globalThis : this);
