"use strict";
// Popup: when the user clicks the toolbar button, read the open tab (activeTab), fill an
// editable form, and save the lot to chrome.storage.local. Nothing leaves the computer.

const $ = (id) => document.getElementById(id);
const usd = (c) => (c < 0 ? "-$" : "$") + Math.round(Math.abs(c) / 100).toLocaleString("en-US");
let pricing = null;
let current = null;

// Runs inside the tab, in the user's own session: a snapshot of what the page shows.
function grabPage() {
  const jsonld = [];
  for (const s of document.querySelectorAll('script[type="application/ld+json"]')) {
    try {
      jsonld.push(JSON.parse(s.textContent));
    } catch {
      /* not JSON: skip */
    }
  }
  const images = [...document.images].slice(0, 300).map((i) => ({
    src: i.currentSrc || i.src,
    w: i.naturalWidth,
    h: i.naturalHeight,
  }));
  return {
    url: location.href,
    title: document.title,
    text: (document.body ? document.body.innerText : "").slice(0, 200000),
    jsonld,
    images,
  };
}

// Runs inside the tab: each results-table row that links to a lot, as plain text.
function grabRows() {
  const rows = [];
  const seen = new Set();
  for (const a of document.querySelectorAll('a[href*="/lot/"]')) {
    const tr = a.closest("tr, [role=row]");
    if (!tr || seen.has(tr)) continue;
    seen.add(tr);
    const img = tr.querySelector("img");
    rows.push({ url: a.href, text: tr.innerText.slice(0, 3000), img: img ? img.currentSrc || img.src : "" });
    if (rows.length >= 500) break;
  }
  return { url: location.href, rows };
}

async function saveAll(found) {
  const { lots = {} } = await chrome.storage.local.get("lots");
  const now = new Date().toISOString();
  let added = 0;
  for (const lot of found) {
    const id = LotStore.lotId(lot);
    const before = lots[id];
    if (!before) added++;
    // A lot saved before keeps the user's parts and value; the bid and facts refresh.
    lots[id] = before
      ? { ...before, current_bid_cents: lot.current_bid_cents ?? before.current_bid_cents, sale_date: lot.sale_date, updated_at: now }
      : { ...lot, id, parts: {}, saved_at: now, updated_at: now };
  }
  await chrome.storage.local.set({ lots });
  $("status").textContent = `Saved ${found.length} lots (${added} new). ${Object.keys(lots).length} in your list.`;
  $("saveAll").hidden = true;
}

function el(tag, attrs = {}, ...kids) {
  const n = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === "text") n.textContent = v;
    else n.setAttribute(k, v);
  }
  for (const k of kids) if (k != null) n.append(k);
  return n;
}

const num = (id) => {
  const v = $(id).value.trim();
  return v === "" ? null : Number(v);
};
const centsOf = (id) => (num(id) == null ? null : Math.round(num(id) * 100));

function buildParts(selected) {
  const box = $("parts");
  box.replaceChildren();
  for (const p of pricing.parts) {
    const s = el("select", { "data-part": p.part, "aria-label": p.label },
      el("option", { value: "", text: "OK" }), el("option", { value: "replace", text: "Replace" }));
    if (p.repair_hours > 0) s.append(el("option", { value: "repair", text: "Repair" }));
    s.value = selected[p.part] || "";
    s.addEventListener("change", update);
    box.append(el("label", { class: "part" }, el("span", { text: p.label }), s));
  }
}

function formLot() {
  const parts = {};
  for (const s of document.querySelectorAll("#parts select")) if (s.value) parts[s.dataset.part] = s.value;
  return {
    ...current,
    year: num("year"),
    make: $("make").value.trim(),
    model: $("model").value.trim(),
    odometer_mi: num("odometer_mi"),
    current_bid_cents: centsOf("bid"),
    title_type: $("title_type").value,
    market_value_cents: centsOf("value"),
    transport_cents: centsOf("transport"),
    parts,
  };
}

function update() {
  const lot = formLot();
  $("partsCount").textContent = Object.keys(lot.parts).length ? `(${Object.keys(lot.parts).length})` : "";
  const d = LotStore.scoreSaved(pricing, lot);
  if (d.error) {
    $("estimate").textContent = "To score it: " + d.error + ".";
    $("estimate").className = "estimate";
    return;
  }
  const value = d.value_known ? "" : " · no value figure for this model: type one in";
  $("estimate").textContent = `Est. margin ${usd(d.margin_cents)} on ${usd(d.all_in_cents)} all-in${value}`;
  $("estimate").className = "estimate " + (d.margin_cents >= 0 ? "pos" : "neg");
}

function fill(lot, savedBefore) {
  current = lot;
  $("year").value = lot.year ?? "";
  $("make").value = lot.make || "";
  $("model").value = lot.model || "";
  $("odometer_mi").value = lot.odometer_mi ?? "";
  $("bid").value = lot.current_bid_cents == null ? "" : String(Math.round(lot.current_bid_cents / 100));
  $("title_type").value = lot.title_type || "salvage";
  $("value").value = lot.market_value_cents == null ? "" : String(lot.market_value_cents / 100);
  $("transport").value = lot.transport_cents == null ? "" : String(lot.transport_cents / 100);
  const facts = [
    { copart: "Copart", iaai: "IAAI", ebay: "eBay", facebook: "Facebook", craigslist: "Craigslist", autobidmaster: "AutoBidMaster" }[lot.source] +
      (lot.lot_number ? " lot " + lot.lot_number : ""),
    lot.primary_damage && "damage: " + lot.primary_damage,
    (() => {
      const f = LotStore.faultsFor(pricing, `${lot.title || ""}\n${lot.description || ""}`);
      return f.faults.length ? "seller says: " + f.faults.map((x) => x.label).join(", ") : f.vague ? "needs work (not said what)" : "";
    })(),
    lot.photos.length + " photo link" + (lot.photos.length === 1 ? "" : "s"),
  ].filter(Boolean);
  $("facts").textContent = facts.join(" · ");
  let parts = lot.parts;
  if (!parts) {
    parts = {};
    const canRepair = Object.fromEntries(pricing.parts.map((p) => [p.part, p.repair_hours > 0]));
    for (const p of LotExtract.suggestParts(lot.primary_damage + " " + lot.secondary_damage)) {
      parts[p] = canRepair[p] ? "repair" : "replace";
    }
  }
  buildParts(parts);
  if (!lot.parts && Object.keys(parts).length) $("partsBox").open = true;
  $("status").textContent = savedBefore
    ? "Already saved: changes update it."
    : "Check the details, tick damaged parts, then save.";
  $("lot").hidden = false;
  update();
}

async function save(e) {
  e.preventDefault();
  const lot = formLot();
  lot.id = LotStore.lotId(lot);
  lot.saved_at = lot.saved_at || new Date().toISOString();
  lot.updated_at = new Date().toISOString();
  const { lots = {} } = await chrome.storage.local.get("lots");
  lots[lot.id] = lot;
  await chrome.storage.local.set({ lots });
  $("status").textContent = `Saved. ${Object.keys(lots).length} lot(s) in your list.`;
}

const openCompare = () => chrome.tabs.create({ url: chrome.runtime.getURL("compare.html") });

async function init() {
  $("open").addEventListener("click", openCompare);
  $("openOnly").addEventListener("click", openCompare);
  $("lot").addEventListener("submit", save);
  for (const id of ["year", "make", "model", "odometer_mi", "bid", "title_type", "value", "transport"]) {
    $(id).addEventListener("input", update);
  }
  pricing = await (await fetch(chrome.runtime.getURL("pricing.json"))).json();
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !LotExtract.sourceOf(tab.url || "")) {
    $("status").textContent = "Open a car on Copart, IAAI, AutoBidMaster, eBay, Facebook Marketplace or Craigslist, then click again.";
    $("openOnly").hidden = false;
    return;
  }
  try {
    const [res] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: grabRows });
    const found = LotExtract.extractRows(res.result);
    if (found.length >= 2) {
      $("status").textContent = `${found.length} lots on this results page.`;
      $("saveAll").textContent = `Save all ${found.length} lots`;
      $("saveAll").hidden = false;
      $("saveAll").onclick = () => saveAll(found);
      $("openOnly").hidden = false;
      return;
    }
  } catch {
    /* not a results page: read it as one lot below */
  }
  let page;
  try {
    const [res] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: grabPage });
    page = res.result;
  } catch (err) {
    $("status").textContent = "Could not read this page: " + err.message;
    $("openOnly").hidden = false;
    return;
  }
  const lot = LotExtract.extractLot(page);
  const { lots = {} } = await chrome.storage.local.get("lots");
  const before = lots[LotStore.lotId(lot)];
  // A lot saved before keeps the user's parts and value; the bid and photos refresh.
  fill(before ? { ...before, current_bid_cents: lot.current_bid_cents ?? before.current_bid_cents, photos: lot.photos.length ? lot.photos : before.photos } : lot, !!before);
}

init();
