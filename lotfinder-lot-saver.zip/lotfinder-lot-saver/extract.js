"use strict";
// Turn what the user's own browser shows on a lot page into a LotFinder lot.
// Input is a plain snapshot made by grabPage() in popup.js:
//   {url, title, text, jsonld: [objects], images: [{src, w, h}]}
// Pure: no DOM, no network, so tests/unit/test_extension.py runs it in node.

(function (root) {
  const MAKES = [
    "alfa romeo", "land rover", "mercedes-benz", "acura", "audi", "bmw", "buick", "cadillac",
    "chevrolet", "chrysler", "dodge", "fiat", "ford", "genesis", "gmc", "honda", "hyundai",
    "infiniti", "jaguar", "jeep", "kia", "lexus", "lincoln", "mazda", "mini", "mitsubishi",
    "nissan", "porsche", "ram", "subaru", "tesla", "toyota", "volkswagen", "volvo",
  ];
  const UPPER = new Set(["bmw", "gmc", "ram", "mini"]);

  function sourceOf(url) {
    let host;
    try {
      host = new URL(url).hostname.toLowerCase();
    } catch {
      return null;
    }
    const is = (d) => host === d || host.endsWith("." + d);
    if (is("copart.com")) return "copart";
    if (is("iaai.com")) return "iaai";
    if (/(^|\.)ebay\.(com|ca|co\.uk|com\.au)$/.test(host)) return "ebay";
    return null;
  }

  function https(u) {
    try {
      const p = new URL(u);
      return p.protocol === "https:" ? p.href : null;
    } catch {
      return null;
    }
  }

  const clean = (s) => String(s == null ? "" : s).replace(/\s+/g, " ").trim();
  const cents = (s) => {
    const m = clean(s).replace(/,/g, "").match(/\$\s*(\d+(?:\.\d{1,2})?)|^(\d+(?:\.\d{1,2})?)/);
    return m ? Math.round(Number(m[1] || m[2]) * 100) : null;
  };
  const miles = (s) => {
    const m = clean(s).replace(/,/g, "").match(/(\d{1,7})/);
    return m ? Number(m[1]) : null;
  };

  // "Label: value" on one line, or the label alone and the value on the next line.
  function labelled(lines, labels) {
    for (const label of labels) {
      const re = new RegExp("^" + label + "\\s*[:#]?\\s*(.*)$", "i");
      for (let i = 0; i < lines.length; i++) {
        const m = lines[i].match(re);
        if (!m) continue;
        const rest = clean(m[1]);
        if (rest) return rest;
        if (i + 1 < lines.length) return lines[i + 1];
      }
    }
    return "";
  }

  function titleType(s) {
    const t = clean(s).toLowerCase();
    if (/parts|non-?repairable|junk|destruction/.test(t)) return "parts-only";
    if (/rebuil|reconstruct|restored/.test(t)) return "rebuilt";
    if (/salvage|lemon|flood|water|theft/.test(t)) return "salvage";
    if (/clean|clear/.test(t)) return "clean";
    return "";
  }

  const cap = (s) => s.replace(/(^|[\s-])([a-z])/g, (m, a, b) => a + b.toUpperCase());
  const niceMake = (m) => (UPPER.has(m) ? m.toUpperCase() : cap(m));
  const niceModel = (m) => {
    const x = clean(m);
    if (/^mx-5 miata$/i.test(x)) return "MX-5 Miata";
    return /\d/.test(x) ? x.toUpperCase() : cap(x.toLowerCase());
  };

  // "2019 Honda Civic LX" -> {year, make, model}; the model is the word after the make.
  function ymm(text) {
    const m = clean(text).match(/\b(19[89]\d|20[0-3]\d)\s+(.+)/);
    if (!m) return {};
    const rest = m[2].toLowerCase();
    const make = MAKES.find((mk) => rest === mk || rest.startsWith(mk + " "));
    if (!make) return { year: Number(m[1]) };
    const words = m[2].slice(make.length).trim().split(" ");
    let model = words[0] || "";
    if (/^mx-5$/i.test(model) && /^miata$/i.test(words[1] || "")) model += " " + words[1];
    if (/^f$/i.test(model) && /^\d{3}$/.test(words[1] || "")) model += "-" + words[1];
    return { year: Number(m[1]), make: niceMake(make), model: niceModel(model) };
  }

  function fromJsonLd(items) {
    const out = {};
    const all = [];
    const walk = (o) => {
      if (Array.isArray(o)) o.forEach(walk);
      else if (o && typeof o === "object") {
        all.push(o);
        if (o["@graph"]) walk(o["@graph"]);
      }
    };
    walk(items || []);
    for (const o of all) {
      const type = [].concat(o["@type"] || []).join(" ").toLowerCase();
      if (!/vehicle|car|product/.test(type)) continue;
      const brand = o.brand && typeof o.brand === "object" ? o.brand.name : o.brand || o.manufacturer;
      if (brand && !out.make) out.make = niceMake(clean(brand).toLowerCase());
      const model = o.model && typeof o.model === "object" ? o.model.name : o.model;
      if (model && !out.model) out.model = niceModel(model);
      const yr = Number(o.vehicleModelDate || o.modelDate || o.productionDate);
      if (yr >= 1980 && yr <= 2039 && !out.year) out.year = yr;
      const odo = o.mileageFromOdometer;
      if (odo != null && out.odometer_mi == null) {
        out.odometer_mi = miles(typeof odo === "object" ? odo.value : odo);
      }
      if (o.vehicleIdentificationNumber && !out.vin) out.vin = clean(o.vehicleIdentificationNumber);
      if (o.name && !out.name) out.name = clean(o.name);
      const offer = [].concat(o.offers || [])[0];
      if (offer && offer.price != null && out.current_bid_cents == null) {
        out.current_bid_cents = cents(String(offer.price));
      }
      for (const img of [].concat(o.image || [])) {
        const u = https(typeof img === "object" ? img.url : img);
        if (u) (out.photos = out.photos || []).push(u);
      }
    }
    return out;
  }

  function photosFrom(images) {
    const out = [];
    for (const img of images || []) {
      const u = https(img.src);
      if (!u || out.includes(u)) continue;
      if ((img.w || 0) < 200 || (img.h || 0) < 120) continue; // icons, logos, thumbnail strips
      out.push(u);
      if (out.length >= 12) break;
    }
    return out;
  }

  function lotNumber(source, url, lines) {
    const typed = labelled(lines, ["lot number", "lot #", "lot", "stock number", "stock #", "item number"]);
    const fromText = (typed.match(/\d{5,14}/) || [""])[0];
    if (fromText) return fromText;
    if (source === "ebay") return (String(url).match(/\/itm\/(?:[^/?#]*\/)?(\d{9,14})/) || ["", ""])[1];
    return (String(url).match(/(\d{6,10})/) || [""])[0];
  }

  function extractLot(page) {
    const source = sourceOf(page.url);
    if (!source) return null;
    const lines = String(page.text || "").split(/\r?\n/).map(clean).filter(Boolean);
    const ld = fromJsonLd(page.jsonld);
    const head = ymm(ld.name || page.title || "");
    const firstCar = lines.slice(0, 60).find((l) => ymm(l).make);
    const body = ymm(firstCar || "");
    const pick = (...xs) => xs.find((x) => x != null && x !== "");
    const bid = cents(labelled(lines, ["current bid", "high bid", "current price", "starting bid"]));
    const vin = labelled(lines, ["vin"]).match(/[A-HJ-NPR-Z0-9]{17}/i);
    const titleText = labelled(lines, ["title code", "title type", "title/sale doc", "sale document", "doc type", "title"]);
    return {
      source,
      url: https(page.url),
      lot_number: lotNumber(source, page.url, lines),
      year: pick(ld.year, head.year, body.year) || null,
      make: pick(ld.make, head.make, body.make) || "",
      model: pick(ld.model, head.model, body.model) || "",
      odometer_mi: pick(ld.odometer_mi, miles(labelled(lines, ["odometer", "mileage", "miles"]))) ?? null,
      current_bid_cents: pick(bid, ld.current_bid_cents) ?? null,
      title_type: titleType(titleText) || "salvage",
      vin: pick(ld.vin, vin && vin[0].toUpperCase()) || "",
      primary_damage: labelled(lines, ["primary damage", "loss type", "damage"]).slice(0, 60),
      secondary_damage: labelled(lines, ["secondary damage"]).slice(0, 60),
      location: labelled(lines, ["location", "selling branch", "item location"]).slice(0, 60),
      sale_date: labelled(lines, ["sale date", "auction date", "time left"]).slice(0, 60),
      photos: [...new Set([...(ld.photos || []), ...photosFrom(page.images)])].slice(0, 12),
    };
  }

  // One row of a search results page (Copart's results table): {url, text, img}.
  // The row has no labels for title or damage, so those come from the line's shape.
  function extractRow(row) {
    const lot = extractLot({ url: row.url, title: "", text: row.text, jsonld: [], images: [] });
    if (!lot || !lot.url || !/\/lot\/\d+/i.test(lot.url)) return null;
    const lines = String(row.text || "").split(/\r?\n/).map(clean).filter(Boolean);
    const car = lines.find((l) => ymm(l).make);
    if (car) Object.assign(lot, ymm(car));
    const title = lines.find((l) => /title|certificate|\bcert\b|bill of sale/i.test(l));
    if (title && titleType(title)) lot.title_type = titleType(title);
    const damage = lines.find((l) => /damage$/i.test(l) || /^(mechanical|normal wear|all over|undercarriage)/i.test(l));
    if (!lot.primary_damage && damage) lot.primary_damage = damage.replace(/\s*damage$/i, "").slice(0, 60);
    const loc = lines.find((l) => /^[A-Z]{2} - [A-Z]/.test(l));
    if (!lot.location && loc) lot.location = loc.slice(0, 60);
    if (!lot.sale_date) lot.sale_date = (lines.find((l) => /^auction in|^sale date|^future/i.test(l)) || "").slice(0, 60);
    const runs = lines.find((l) => /run and drive|engine starts|enhanced vehicles|stationary/i.test(l));
    lot.condition = runs ? runs.slice(0, 40) : "";
    const img = https(row.img);
    lot.photos = img ? [img] : [];
    return lot;
  }

  function extractRows(page) {
    const out = [];
    const seen = new Set();
    for (const row of (page && page.rows) || []) {
      const lot = extractRow(row);
      if (!lot || seen.has(lot.lot_number)) continue;
      seen.add(lot.lot_number);
      out.push(lot);
    }
    return out;
  }

  // Damage words -> parts to look at first. Only a suggestion: the user ticks what is real.
  const DAMAGE_PARTS = [
    [/front/i, ["front_bumper", "hood", "grille", "headlight_left", "headlight_right"]],
    [/rear/i, ["rear_bumper", "trunk_lid", "taillight_left", "taillight_right"]],
    [/left|driver/i, ["fender_left", "door_front_left", "door_rear_left"]],
    [/right|passenger/i, ["fender_right", "door_front_right", "door_rear_right"]],
    [/roof|rollover|top/i, ["roof", "windshield"]],
    [/hail/i, ["hail_dents"]],
  ];
  function suggestParts(damageText) {
    const out = [];
    for (const [re, parts] of DAMAGE_PARTS) {
      if (re.test(damageText || "")) for (const p of parts) if (!out.includes(p)) out.push(p);
    }
    return out;
  }

  const LotExtract = { extractLot, extractRows, sourceOf, suggestParts, https };
  if (typeof module !== "undefined" && module.exports) module.exports = LotExtract;
  else root.LotExtract = LotExtract;
})(typeof globalThis !== "undefined" ? globalThis : this);
